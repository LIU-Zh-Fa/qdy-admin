export default {
  sidebar: {
    homePage: 'home page'
  }
}
