export default {
  sidebar: {
    homePage: 'Página'
  }
}