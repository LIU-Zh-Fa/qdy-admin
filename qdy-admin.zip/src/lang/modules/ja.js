export default {
  sidebar: {
    homePage: '最初のページ'
  }
}
