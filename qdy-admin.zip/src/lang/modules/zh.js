export default {
  sidebar: {
    homePage: '首页'
  }
}
