<template>
  <div>
    this is a demo
  </div>
</template>

<script>
  export default {
    name: 'Demo'
  }
</script>

<style lang="scss" scoped>
</style>
