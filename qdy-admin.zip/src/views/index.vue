<template>
  <div class="dashboard-editor-container">
    敬请期待。。。
  </div>
</template>

<script>
export default {
  name: 'Index'
}
</script>

<style lang="scss" scoped>
</style>
