//订单状态
export const statusOptions = [
    {
      value: '0',
      label: '已取消',
    },
    {
      value: '1',
      label: '待取件',
    },
    {
        value: '2',
        label: '已完成',
    }
  ]  